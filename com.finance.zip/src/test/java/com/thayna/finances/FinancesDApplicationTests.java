package com.thayna.finances;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinancesDApplicationTests {

	@Test
	void contextLoads() {
	}

}
